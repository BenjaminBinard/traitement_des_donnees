var searchData=
[
  ['mysql_5fconnection',['MySQL_Connection',['../classsql_1_1mysql_1_1MySQL__Connection.html',1,'sql::mysql']]],
  ['mysql_5fsavepoint',['MySQL_Savepoint',['../classsql_1_1mysql_1_1MySQL__Savepoint.html',1,'sql::mysql']]]
];
