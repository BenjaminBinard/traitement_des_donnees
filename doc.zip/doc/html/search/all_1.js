var searchData=
[
  ['comparaison',['Comparaison',['../classDataBase.html#a65ad879d829e20db4a78719e62c8356e',1,'DataBase']]],
  ['createalert',['createAlert',['../classDataBase.html#aa1c151b2f7d0adb2a2a7a692db65e3f4',1,'DataBase']]]
];
