var searchData=
[
  ['getbddip',['getBddIp',['../classEchoClient.html#a3f7731443eebfdb9dc3484aa9f44d0db',1,'EchoClient']]],
  ['getbddlogin',['getBddLogin',['../classEchoClient.html#a4e8b1f06f6149d913b87786d0b926c2b',1,'EchoClient']]],
  ['getbddpassword',['getBddPassword',['../classEchoClient.html#afefb25861ae733ed0b74ace091843ab3',1,'EchoClient']]],
  ['getidroom',['getIdRoom',['../classEchoClient.html#a7c173d78a32ebadb5bd8320ebcef25b9',1,'EchoClient']]]
];
