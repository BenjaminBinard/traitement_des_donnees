var indexSectionsWithContent =
{
  0: "acdeglmqt",
  1: "demq",
  2: "dem",
  3: "acdegt",
  4: "l"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "pages"
};

var indexSectionLabels =
{
  0: "Tout",
  1: "Classes",
  2: "Fichiers",
  3: "Fonctions",
  4: "Pages"
};

